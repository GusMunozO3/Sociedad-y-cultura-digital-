// LOGIN
function login() {
    let user = document.getElementById("user").value;
    let pass = document.getElementById("pass").value;

    if (user === "admin" && pass === "1234") {
        localStorage.setItem("login", "true");
        window.location.href = "index.html";
    } else {
        document.getElementById("error").innerText = "❌ Error";
    }
}

// PROTEGER
if (window.location.pathname.includes("index.html") || window.location.pathname.includes("edit.html")) {
    if (localStorage.getItem("login") !== "true") {
        window.location.href = "login.html";
    }
}

// LOGOUT
function logout() {
    localStorage.removeItem("login");
    window.location.href = "login.html";
}

// TYPEWRITER
let text = "Las fake news son noticias falsas diseñadas para manipular la opinión pública...";
let i = 0;

function escribir() {
    let el = document.getElementById("typeText");
    if (el && i < text.length) {
        el.innerHTML += text.charAt(i);
        i++;
        setTimeout(escribir, 40);
    }
}
setTimeout(escribir, 1000);

// GUARDAR TEXTO
function guardar() {
    let contenido = document.getElementById("contenido").value;
    localStorage.setItem("textoEditado", contenido);
    document.getElementById("preview").innerText = contenido;
}

// CARGAR TEXTO
window.onload = function() {
    let data = localStorage.getItem("textoEditado");
    if (data) {
        let preview = document.getElementById("preview");
        if (preview) preview.innerText = data;
    }
};

// PARTÍCULAS
const canvas = document.getElementById("particles");
if (canvas) {
    const ctx = canvas.getContext("2d");

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    let particles = [];

    for (let i = 0; i < 60; i++) {
        particles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            size: 2,
            speedX: Math.random() - 0.5,
            speedY: Math.random() - 0.5
        });
    }

    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        particles.forEach(p => {
            p.x += p.speedX;
            p.y += p.speedY;

            ctx.fillStyle = "#00ffcc";
            ctx.fillRect(p.x, p.y, p.size, p.size);
        });

        requestAnimationFrame(animate);
    }

    animate();
}